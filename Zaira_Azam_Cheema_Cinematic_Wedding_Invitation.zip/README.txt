ZAIRA AZAM CHEEMA — THE LUXURY ANIMATED WEDDING INVITATION
===============================================================

IMPORTANT: This is a complete, mobile-first HTML wedding invitation website.
Open index.html to preview. The five optimized animated artwork backdrops
are static art with lightweight animated HTML/CSS overlays in the browser.
No video downloads or software dependencies are required.

HOW TO PUT IT ONLINE:
1. Go to https://app.netlify.com/drop
2. Drag and drop this ZIP (or unzip and drag this folder).
3. Copy the public URL that Netlify gives you and send it by WhatsApp.

EVENTS (all Pakistan Standard Time UTC+05:00):
- Bridal Shower: Wednesday, 18 November 2026, 2:00 PM
- Ubtan & Dholak: Wednesday, 18 November 2026, 8:00 PM
- Mehndi: Thursday, 19 November 2026, 6:00 PM
- Baraat: Saturday, 21 November 2026, 12:00 PM
- Baraat venue: Castel. Full map pin still needed.
- Other event venues: not yet supplied.
- RSVP/contacts: 0332-4924669 / 0300-6421436

FEATURES:
- Cinematic luxury envelope with rising invitation card
- Original editorial visuals / moving lighting / floral petals
- Four color-coordinated animated event backgrounds
- Bismillah, Qur'anic verse excerpt, formal invitation and closing dua
- Calendar downloads, countdown, call links and WhatsApp RSVPs
- Event location request links (accurate map pins still needed)
- Reduced-motion accessibility and sharp selectable text
- Social share preview image (og-preview.png)

IMPORTANT BEFORE FINAL PUBLIC DISTRIBUTION:
- Add correct full venue addresses and map pins when available.
- In index.html, use a full public https://.../og-preview.png URL for og:image
  once the final deployment domain is known, for best WhatsApp previews.
- Exact ending times for the calendar are approximate placeholders.
- The website is not publicly hosted until you deploy it.

All text is editable in index.html. Images are in /assets/.
